import React from 'react'

const slides = () => {
  return (
    <div>slides</div>
  )
}

export default slides