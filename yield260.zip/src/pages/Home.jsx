import React from 'react'
import Hero from '../components/elements/Hero'

const Home = () => {
  return (
    <>
    <Hero />
    </>
  )
}

export default Home