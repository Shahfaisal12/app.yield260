
import './App.scss';
import 'bootstrap/dist/css/bootstrap.min.css'
import RoutesPage from './pages/routesPage/RoutesPage.jsx'
import { getBSCContractInstance } from './utils/web3';
import { useEffect } from 'react';

function App() {
  useEffect(() => {
    const getContractData = async () => {
      try {
        const contractBsc = getBSCContractInstance()
        const tokenDecimals = await contractBsc.methods.decimals().call()
        let maxSupply = await contractBsc.methods.totalSupply().call()
        maxSupply = maxSupply / (10 ** tokenDecimals)
        let circulatingSupply = await contractBsc.methods.getCirculatingSupply().call()
        circulatingSupply = circulatingSupply / (10 ** tokenDecimals)
        let firePit = await contractBsc.methods.firePitFee().call()
        console.log({ maxSupply, circulatingSupply, firePit })
      } catch (error) {
        console.log({ error })
      }
    }
    getContractData()
  }, [])

  return (
    <div className="App">
      <RoutesPage />
    </div>
  );
}

export default App;
